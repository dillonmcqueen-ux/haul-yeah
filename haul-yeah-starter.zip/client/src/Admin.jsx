import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function Admin(){
  const [bookings, setBookings] = useState([]);
  const [password, setPassword] = useState('');

  async function load(){
    try {
      const res = await axios.get('/api/admin/bookings', { headers: { 'x-admin-password': password } });
      setBookings(res.data);
    } catch (err) {
      alert('Failed to load bookings. Check admin password.');
    }
  }

  return (
    <div>
      <h2>Admin</h2>
      <p>Enter admin password and click Load</p>
      <input type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button onClick={load}>Load</button>
      <table>
        <thead><tr><th>ID</th><th>Name</th><th>Trailer</th><th>Hitch</th><th>Dates</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody>
          {bookings.map(b=> (
            <tr key={b.id}>
              <td>{b.id}</td>
              <td>{b.customer_name}</td>
              <td>{b.trailer_type}</td>
              <td>{b.hitch_selected ? 'Yes' : 'No'}</td>
              <td>{b.start_date} → {b.end_date}</td>
              <td>${(b.total_amount_cents/100).toFixed(2)}</td>
              <td>{b.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
