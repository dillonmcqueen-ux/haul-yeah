import React, { useState } from 'react'
import BookingForm from './BookingForm'
import Admin from './Admin'

export default function App(){
  const [view, setView] = useState('book');
  return (
    <div className="container">
      <header>
        <div style={{display:'flex', alignItems:'center'}}>
          <img src="/logo.png" alt="logo" style={{height:60, marginRight:12}}/>
          <h1>Haul-Yeah Rentals</h1>
        </div>
        <nav>
          <button onClick={()=>setView('book')}>Book</button>
          <button onClick={()=>setView('admin')}>Admin</button>
        </nav>
      </header>
      <main>
        {view === 'book' ? <BookingForm /> : <Admin />}
      </main>
    </div>
  )
}
