import React, { useRef, useState } from 'react'
import SignaturePad from 'react-signature-canvas'
import axios from 'axios'

export default function BookingForm(){
  const [form, setForm] = useState({ customer_name:'', email:'', phone:'', trailer_type:'6x12 Enclosed Trailer', start_date:'', end_date:'', hitch:false });
  const [bookingId, setBookingId] = useState(null);
  const sigRef = useRef(null);
  const [step, setStep] = useState(1);

  async function submitBooking(e){
    e.preventDefault();
    const res = await axios.post('/api/bookings', form);
    setBookingId(res.data.bookingId);
    if (res.data.checkoutUrl) {
      window.location = res.data.checkoutUrl;
    } else {
      setStep(2);
    }
  }

  async function saveSignature(){
    const dataUrl = sigRef.current.getTrimmedCanvas().toDataURL('image/png');
    const res = await axios.post(`/api/bookings/${bookingId}/signature`, { signature: dataUrl });
    if (res.data.ok) alert('Signature saved and contract generated. Check your email.');
  }

  return (
    <div>
      {step === 1 && (
        <form onSubmit={submitBooking} className="form">
          <h2>Book a trailer</h2>
          <input required placeholder="Full name" value={form.customer_name} onChange={e=>setForm({...form, customer_name:e.target.value})} />
          <input placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />
          <input placeholder="Phone" value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} />
          <select value={form.trailer_type} onChange={e=>setForm({...form, trailer_type:e.target.value})}>
            <option>6x12 Enclosed Trailer</option>
            <option>Car Dolly</option>
            <option>Dump Trailer (coming soon)</option>
          </select>
          <label>Start date</label>
          <input required type="date" value={form.start_date} onChange={e=>setForm({...form, start_date:e.target.value})} />
          <label>End date</label>
          <input required type="date" value={form.end_date} onChange={e=>setForm({...form, end_date:e.target.value})} />
          <div style={{margin:'8px 0'}}>
            <label><input type="checkbox" checked={form.hitch} onChange={e=>setForm({...form, hitch:e.target.checked})} /> Add hitch rental ($20 flat)</label>
          </div>
          <button type="submit">Continue to payment</button>
        </form>
      )}

      {step === 2 && (
        <div>
          <h3>Sign on iPad</h3>
          <SignaturePad ref={sigRef} canvasProps={{width:600, height:200, className:'sig'}} />
          <div>
            <button onClick={()=>sigRef.current.clear()}>Clear</button>
            <button onClick={saveSignature}>Save signature</button>
          </div>
        </div>
      )}
    </div>
  )
}
