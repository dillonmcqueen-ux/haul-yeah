Haul-Yeah Starter App

What's included: minimal server + client with hitch rental option ($20 flat), Stripe integration (test keys), signature capture, and PDF contract generation.

To run locally:
1. Install Node.js
2. cd server
3. npm install
4. cp .env.example .env and edit keys
5. npm run migrate
6. npm start
7. In another terminal, cd client && npm install && npm run dev

The public/logo.png already contains your provided logo.
