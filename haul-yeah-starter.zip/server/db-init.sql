CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT,
  email TEXT,
  phone TEXT,
  trailer_type TEXT,
  start_date TEXT,
  end_date TEXT,
  total_amount_cents INTEGER,
  stripe_session_id TEXT,
  status TEXT DEFAULT 'pending',
  hitch_selected INTEGER DEFAULT 0,
  signed_at TEXT,
  signature_path TEXT,
  contract_pdf_path TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER,
  amount_cents INTEGER NOT NULL,
  description TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
