require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || '');
const nodemailer = require('nodemailer');
const puppeteer = require('puppeteer');

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '8mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const DB_FILE = process.env.DATABASE_FILE || './data.db';
const db = new Database(DB_FILE);

// simple email helper (configure SMTP in .env)
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || '',
  port: Number(process.env.SMTP_PORT || 587),
  secure: false,
  auth: { user: process.env.SMTP_USER || '', pass: process.env.SMTP_PASS || '' }
});

function centsToCurrency(cents) {
  return (cents/100).toFixed(2);
}

// pricing function: daily rate + optional hitch flat fee ($20)
function calculateAmountCents(trailer_type, start_date, end_date, hitch_selected) {
  const MS_PER_DAY = 1000*60*60*24;
  const days = Math.max(1, Math.ceil((new Date(end_date) - new Date(start_date)) / MS_PER_DAY));
  let ratePerDay = 6000; // $60.00 default in cents
  if (trailer_type && trailer_type.toLowerCase().includes('dolly')) ratePerDay = 6000; // keep $60/day for dolly per user earlier
  // default rate mapping could be extended
  let total = ratePerDay * days;
  if (hitch_selected) {
    total += 2000; // $20.00 flat for entire rental (in cents)
  }
  return total;
}

// Init DB if not exists
const initSql = fs.readFileSync(path.join(__dirname, 'db-init.sql'), 'utf8');
db.exec(initSql);

// create booking and return Stripe checkout URL
app.post('/api/bookings', async (req, res) => {
  const { customer_name, email, phone, trailer_type, start_date, end_date, hitch } = req.body;
  if (!customer_name || !start_date || !end_date) return res.status(400).json({ error: 'Missing required fields' });
  const amount = calculateAmountCents(trailer_type, start_date, end_date, hitch);
  const insert = db.prepare(`INSERT INTO bookings (customer_name,email,phone,trailer_type,start_date,end_date,total_amount_cents,hitch_selected) VALUES (?,?,?,?,?,?,?,?)`);
  const info = insert.run(customer_name, email, phone, trailer_type, start_date, end_date, amount, hitch ? 1 : 0);
  const bookingId = info.lastInsertRowid;

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: 'cad',
          product_data: { name: `${trailer_type} rental` },
          unit_amount: amount
        },
        quantity: 1
      }],
      success_url: `${process.env.PUBLIC_URL || 'http://localhost:5173'}/success?bookingId=${bookingId}`,
      cancel_url: `${process.env.PUBLIC_URL || 'http://localhost:5173'}/cancel`,
      metadata: { bookingId: String(bookingId) }
    });
    db.prepare('UPDATE bookings SET stripe_session_id = ? WHERE id = ?').run(session.id, bookingId);
    res.json({ checkoutUrl: session.url, bookingId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Stripe error' });
  }
});

// stripe webhook
app.post('/api/webhook', bodyParser.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature error', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const bookingId = session.metadata.bookingId;
    db.prepare("UPDATE bookings SET status='paid' WHERE id = ?").run(bookingId);
  }
  res.json({ received: true });
});

// Save signature (dataURL) and generate PDF contract with puppeteer
app.post('/api/bookings/:id/signature', async (req, res) => {
  try {
    const id = req.params.id;
    const { signature } = req.body;
    if (!signature) return res.status(400).json({ error: 'No signature' });
    const base64 = signature.split(',')[1];
    const sigDir = path.join(__dirname, 'signatures');
    if (!fs.existsSync(sigDir)) fs.mkdirSync(sigDir, { recursive: true });
    const sigPath = path.join(sigDir, `signature_booking_${id}.png`);
    fs.writeFileSync(sigPath, Buffer.from(base64, 'base64'));

    // generate contract HTML from template and write PDF using puppeteer
    const tmpl = fs.readFileSync(path.join(__dirname, 'templates', 'contract.html'), 'utf8');
    const booking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);
    const html = tmpl.replace(/\{\{customer_name\}\}/g, booking.customer_name || '')
      .replace(/\{\{start_date\}\}/g, booking.start_date || '')
      .replace(/\{\{end_date\}\}/g, booking.end_date || '')
      .replace(/\{\{trailer_type\}\}/g, booking.trailer_type || '')
      .replace(/\{\{amount\}\}/g, centsToCurrency(booking.total_amount_cents || 0))
      .replace(/\{\{signature_path\}\}/g, `file://${sigPath}`);

    const browser = await puppeteer.launch({ args: ['--no-sandbox','--disable-setuid-sandbox'] });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const contractsDir = path.join(__dirname, 'contracts');
    if (!fs.existsSync(contractsDir)) fs.mkdirSync(contractsDir, { recursive: true });
    const pdfPath = path.join(contractsDir, `contract_${id}.pdf`);
    await page.pdf({ path: pdfPath, format: 'A4', printBackground: true });
    await browser.close();

    db.prepare('UPDATE bookings SET signature_path = ?, contract_pdf_path = ?, signed_at = CURRENT_TIMESTAMP WHERE id = ?').run(sigPath, pdfPath, id);

    if (booking.email) {
      await transporter.sendMail({
        from: process.env.SMTP_USER || 'no-reply@example.com',
        to: booking.email,
        subject: `Your rental contract — Booking ${id}`,
        text: `Thanks! Attached is your contract for booking ${id}`,
        attachments: [{ filename: `contract_${id}.pdf`, path: pdfPath }]
      });
    }

    res.json({ ok: true, contractPdf: `/contracts/contract_${id}.pdf` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to save signature or generate PDF' });
  }
});

// serve contract PDFs
app.use('/contracts', express.static(path.join(__dirname, 'contracts')));

// admin endpoints
app.get('/api/admin/bookings', (req, res) => {
  const auth = req.headers['x-admin-password'];
  if (!auth || auth !== process.env.ADMIN_PASSWORD) return res.status(403).json({ error: 'Forbidden' });
  const rows = db.prepare('SELECT * FROM bookings ORDER BY created_at DESC').all();
  res.json(rows);
});

app.post('/api/admin/expenses', (req, res) => {
  const auth = req.headers['x-admin-password'];
  if (!auth || auth !== process.env.ADMIN_PASSWORD) return res.status(403).json({ error: 'Forbidden' });
  const { booking_id, amount_cents, description } = req.body;
  const insert = db.prepare('INSERT INTO expenses (booking_id, amount_cents, description) VALUES (?,?,?)');
  const info = insert.run(booking_id || null, amount_cents, description);
  res.json({ ok: true, id: info.lastInsertRowid });
});

app.listen(process.env.PORT || 4000, () => console.log('Server running on', process.env.PORT || 4000));
