const fs = require('fs');
const Database = require('better-sqlite3');
const sql = fs.readFileSync('./db-init.sql', 'utf8');
const db = new Database('./data.db');
db.exec(sql);
console.log('Database initialized (data.db)');
